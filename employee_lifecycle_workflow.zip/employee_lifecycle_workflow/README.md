# Employee Lifecycle Workflow Automation & Audit System

A reproducible, synthetic-data project that models employee pre-boarding, access provisioning, equipment delivery, and offboarding across HR, IT, managers, and facilities.

## Features

- Relational master data and transaction/event data for all 12 required entities.
- Deterministic IDs and a fixed random seed (`20261022`).
- Starter and full-scale data generation using the same generator.
- CSV, JSON, and SQLite exports.
- Explicit audit events and a separate `ground_truth.csv` / `ground_truth.json`.
- Five labelled edge cases: access before start, duplicate asset assignment, active grant after termination, task dependency cycle, and recovered asset still assigned.
- Structural validation and pytest coverage.
- Synthetic-only provenance; no real employee or confidential data.

## Requirements

- Python 3.10+
- No runtime third-party dependencies.
- `pytest` is required only to run the tests.

## Quick start

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -e ".[dev]"
python -m lifecycle.generator --scale starter --output data
python -m lifecycle.validate --data data
pytest -q
```

Generate the requested full dataset:

```bash
python -m lifecycle.generator --scale full --output data --seed 20261022
```

Expected full-scale core counts:
- 1,000 employees
- 8,000 tasks
- 1,500 access grants
- 1,200 assets

The generator also creates departments, roles, managers, onboarding cases, dependencies, access roles, offboarding cases, audit events, and ground-truth labels.

## Output files

| File | Description |
|---|---|
| `data/*.csv` | One CSV per entity |
| `data/*.json` | One JSON array per entity |
| `data/lifecycle.db` | SQLite database with PK/FK constraints |
| `data/ground_truth.csv/json` | Expected anomaly labels, separate from input tables |
| `data/validation_summary.json` | Row-count and SQLite FK validation |
| `data/source_manifest.json` | Seed, provenance, row counts, SHA-256 checksums |

## Data model and cardinality

- Department 1:N Role, Manager, Employee.
- Role 1:N Employee.
- Manager 1:N Employee.
- Employee 1:1 OnboardingCase (unique employee FK).
- Employee 1:N Task, AccessGrant, Asset assignment history reference, OffboardingCase (at most one case).
- AccessRole 1:N AccessGrant.
- Task N:M Task through Dependency (two task foreign keys).
- AuditEvent is an append-only event record; `entity_type` + `entity_id` is a polymorphic reference and intentionally not a hard FK.
- Employee role/department/manager fields represent current assignment; changes are retained as AuditEvent records.

## Business rules

1. Employee, Role, Department, Manager and OnboardingCase are generated before dependent transactions.
2. Tasks use stable case-scoped IDs. Dependency rows point to valid task IDs.
3. Access grants have request, approval and grant timestamps. Normal grants begin no earlier than employee start and have approval before grant.
4. Terminated employees receive offboarding cases and urgent revoke/recovery tasks.
5. Asset assignments include acknowledgement timestamps.
6. Derived statuses and anomaly labels are based on source records and documented rules.
7. Known injected anomalies are marked in `issue_type` and recorded separately in ground truth. Ground truth must not be used as a model input feature.

## Validation

`python -m lifecycle.validate --data data` checks PK uniqueness, FK references in exported CSVs, dependency graph cycles, active grants on terminated employees, duplicate assigned assets, and recovered assets retaining employee assignments. The intentionally injected exceptions are reported as detected conditions, not treated as structural corruption.

SQLite FK constraints are enabled during insertion. `PRAGMA foreign_key_check` is recorded in `validation_summary.json`.

## Reproducibility

Run the generator twice with the same seed and scale. The CSV outputs are deterministic; compare SHA-256 hashes in each `source_manifest.json`. The pytest suite also compares representative CSV files byte-for-byte.

## Entity dictionary

See [`docs/data_dictionary.md`](docs/data_dictionary.md) for fields, types, nullability, enums, uniqueness and validation guidance.

## Repository structure

```text
employee_lifecycle_workflow/
├── data/                 # generated exports (created by command)
├── docs/
│   └── data_dictionary.md
├── src/lifecycle/
│   ├── __init__.py
│   ├── generator.py
│   └── validate.py
├── tests/
│   └── test_generator.py
├── .gitignore
└── pyproject.toml
```

## GitHub submission

```bash
git init
git add .
git commit -m "Build employee lifecycle workflow automation project"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/employee-lifecycle-workflow.git
git push -u origin main
```

Make the repository **Public** in GitHub repository settings before submitting. Do not upload real employee data, credentials, access tokens, or private information.
