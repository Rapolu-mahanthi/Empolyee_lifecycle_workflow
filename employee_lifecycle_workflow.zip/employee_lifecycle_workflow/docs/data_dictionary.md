# Data Dictionary

Conventions: IDs are immutable strings; dates use ISO-8601 `YYYY-MM-DD`; timestamps use ISO-8601 local synthetic timestamps. Empty CSV cells represent nullable fields. All records are synthetic.

| Entity | Primary key | Fields (type; required unless marked optional) | Relationships / validation |
|---|---|---|---|
| Department | `department_id` | `department_name` string; `cost_center` string; `active` boolean | Name and cost center unique. One department has many roles, managers and employees. |
| Role | `role_id` | `role_name` string; `department_id` FK; `access_tier` enum STANDARD/RESTRICTED/PRIVILEGED/LIMITED; `active` boolean | Role name unique; department must exist. One role maps to many employees. |
| Manager | `manager_id` | `manager_name` string; `department_id` FK; `email` email; `active` boolean | Email unique; department must exist. One manager may supervise many employees. |
| Employee | `employee_id` | `first_name`, `last_name`, `email`, `role_id` FK, `department_id` FK, `manager_id` FK, `employment_type` enum, `hire_date`, `start_date`, `termination_date` optional, `employment_status` enum, `location`, `issue_type` optional | Email unique. Hire date <= start date; termination date >= start date. Role/department/manager must exist. |
| OnboardingCase | `onboarding_case_id` | `employee_id` unique FK; `case_status` enum; `created_at`; `target_start_date`; `actual_start_date` optional; `hr_owner`; `issue_type` optional | Employee-to-case is 1:1. Created timestamp should not exceed target start date in baseline. |
| Task | `task_id` | `case_id`; `employee_id` FK; `task_type`; `owner_type`; `assigned_to`; `status` enum; `priority` enum; `created_at`; `due_date`; `completed_at` optional; `issue_type` optional | Case ID references onboarding/offboarding case namespace. Employee must exist. Completed tasks require completed_at. |
| Dependency | `dependency_id` | `task_id` FK; `prerequisite_task_id` FK; `dependency_type` enum FINISH_TO_START | Task-to-task N:M via bridge table. Self-dependency and cycles are invalid in normal workflow; one labelled cycle is injected for testing. |
| AccessRole | `access_role_id` | `access_role_name`; `access_tier`; `description` | Access role name unique. One access role may be granted many times. |
| AccessGrant | `access_grant_id` | `employee_id` FK; `access_role_id` FK; `requested_at`; `approved_at`; `granted_at`; `revoked_at` optional; `grant_status` enum; `approved_by`; `issue_type` optional | Employee and access role must exist. Baseline: requested <= approved <= granted; grant active only for eligible employment. |
| Asset | `asset_id` | `asset_type` enum LAPTOP/MONITOR/MOBILE/ACCESS_CARD; `serial_number`; `manufacturer`; `asset_status` enum; `assigned_employee_id` optional FK; `assigned_date` optional; `acknowledged_at` optional; `recovered_at` optional; `issue_type` optional | Serial number unique. Assigned assets require employee and assigned date; recovered assets should have no active assignee in a clean baseline. |
| OffboardingCase | `offboarding_case_id` | `employee_id` unique FK; `initiated_at`; `effective_termination_date`; `case_status` enum; `reason_category`; `issue_type` optional | Employee-to-offboarding is 0:1. Employee must be terminated; effective date matches employee termination date. |
| AuditEvent | `audit_event_id` | `entity_type`; `entity_id`; `event_time`; `action` enum; `old_value`; `new_value`; `actor`; `reason`; `correlation_id` | Append-only history. Polymorphic entity reference is not a physical FK; validate entity type/ID in application logic. |

## ID formats

- Employee: `EMP-000001`
- Onboarding: `ONB-2026-000001`
- Task: `TASK-<case-id>-001`
- Grant: `GRANT-<employee-id>-001`
- Asset: `AST-000001`
- Offboarding: `OFF-2026-000001`
- Audit event: `AUD-0000001`
- Dependency: `DEP-0000001`

## Units and uniqueness

- All dates/times are ISO strings; no numeric time units.
- Employee email, manager email, department name, role name, access role name, asset serial number and all primary IDs are unique.
- `issue_type` is blank for ordinary rows and populated only for deliberately injected anomaly records.
- The ground-truth label file is an evaluation artifact, not a source feature.
