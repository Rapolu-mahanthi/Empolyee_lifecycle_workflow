import csv
import json
from pathlib import Path
from lifecycle.generator import generate
from lifecycle.validate import validate_dataset, detect_cycles

def test_starter_counts_and_labels(tmp_path):
    out = tmp_path / "data"
    result = generate("starter", out, 20261022)
    assert len(result["tables"]["Employee"]) == 100
    assert len(result["tables"]["Task"]) == 800
    assert len(result["tables"]["AccessGrant"]) == 150
    assert len(result["tables"]["Asset"]) == 120
    assert len(result["ground_truth"]) == 5
    assert (out / "lifecycle.db").exists()

def test_reproducible_csv_checksums(tmp_path):
    a, b = tmp_path / "a", tmp_path / "b"
    generate("starter", a, 20261022)
    generate("starter", b, 20261022)
    for name in ["employee.csv", "task.csv", "accessgrant.csv", "asset.csv", "ground_truth.csv"]:
        assert (a / name).read_bytes() == (b / name).read_bytes()

def test_validator_detects_injected_edge_cases(tmp_path):
    out = tmp_path / "data"
    generate("starter", out, 20261022)
    result = validate_dataset(out)
    assert result["passed_structural_checks"]
    assert result["dependency_cycle_detected"]
    assert result["active_grants_for_terminated_employees"]
    assert result["employees_with_multiple_assigned_assets"]
    assert result["recovered_assets_still_assigned"]

def test_cycle_detector():
    rows = [
        {"task_id":"T1","prerequisite_task_id":"T2"},
        {"task_id":"T2","prerequisite_task_id":"T1"},
    ]
    assert detect_cycles(rows)
