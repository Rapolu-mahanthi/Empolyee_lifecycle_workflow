"""Employee lifecycle workflow automation sample project."""
__version__ = "1.0.0"
