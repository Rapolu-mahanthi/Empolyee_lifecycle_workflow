from __future__ import annotations
import csv
import json
import sqlite3
from pathlib import Path
from collections import defaultdict, deque

def read_csv(path: Path):
    with path.open(newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))

def detect_cycles(dependencies):
    graph = defaultdict(list)
    nodes = set()
    for d in dependencies:
        graph[d["task_id"]].append(d["prerequisite_task_id"])
        nodes.update([d["task_id"], d["prerequisite_task_id"]])
    visiting, visited = set(), set()
    def visit(node):
        if node in visiting:
            return True
        if node in visited:
            return False
        visiting.add(node)
        for nxt in graph[node]:
            if visit(nxt):
                return True
        visiting.remove(node)
        visited.add(node)
        return False
    return any(visit(n) for n in nodes if n not in visited)

def validate_dataset(data_dir: str | Path):
    p = Path(data_dir)
    employees = read_csv(p / "employee.csv")
    grants = read_csv(p / "accessgrant.csv")
    assets = read_csv(p / "asset.csv")
    deps = read_csv(p / "dependency.csv")
    truth = read_csv(p / "ground_truth.csv")
    errors = []
    emp_ids = {e["employee_id"] for e in employees}
    task_ids = {t["task_id"] for t in read_csv(p / "task.csv")}
    # Primary key and FK checks.
    for filename, key in [("employee.csv","employee_id"),("task.csv","task_id"),
                          ("accessgrant.csv","access_grant_id"),("asset.csv","asset_id")]:
        rows = read_csv(p / filename)
        vals = [r[key] for r in rows]
        if len(vals) != len(set(vals)):
            errors.append(f"duplicate primary key in {filename}")
    for g in grants:
        if g["employee_id"] not in emp_ids:
            errors.append(f"grant has unknown employee: {g['access_grant_id']}")
    for a in assets:
        if a["assigned_employee_id"] and a["assigned_employee_id"] not in emp_ids:
            errors.append(f"asset has unknown employee: {a['asset_id']}")
    for d in deps:
        if d["task_id"] not in task_ids or d["prerequisite_task_id"] not in task_ids:
            errors.append(f"dependency has unknown task: {d['dependency_id']}")
    cycle = detect_cycles(deps)
    # Labelled anomalies are expected; validator reports them rather than hiding them.
    active_grants_after_termination = []
    status = {e["employee_id"]: e["employment_status"] for e in employees}
    for g in grants:
        if g["grant_status"] == "ACTIVE" and status.get(g["employee_id"]) == "TERMINATED":
            active_grants_after_termination.append(g["access_grant_id"])
    duplicate_assets = defaultdict(list)
    for a in assets:
        if a["asset_status"] == "ASSIGNED" and a["assigned_employee_id"]:
            duplicate_assets[a["assigned_employee_id"]].append(a["asset_id"])
    recovered_still_assigned = [a["asset_id"] for a in assets
        if a["asset_status"] == "RECOVERED" and a["assigned_employee_id"]]
    result = {
        "structural_errors": errors,
        "dependency_cycle_detected": cycle,
        "active_grants_for_terminated_employees": active_grants_after_termination,
        "employees_with_multiple_assigned_assets": {k:v for k,v in duplicate_assets.items() if len(v)>1},
        "recovered_assets_still_assigned": recovered_still_assigned,
        "ground_truth_labels": len(truth),
        "passed_structural_checks": len(errors) == 0,
    }
    return result

def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", default="data")
    args = parser.parse_args()
    result = validate_dataset(args.data)
    print(json.dumps(result, indent=2))
    if not result["passed_structural_checks"]:
        raise SystemExit(1)

if __name__ == "__main__":
    main()
