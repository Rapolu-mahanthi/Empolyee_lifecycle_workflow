from __future__ import annotations

import argparse
import csv
import hashlib
import json
import random
import sqlite3
from collections import Counter, defaultdict
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any

SEED = 20261022
BASE_DATE = date(2026, 1, 1)

ENUMS = {
    "employee_status": ["PREBOARDING", "ACTIVE", "ON_LEAVE", "TERMINATED"],
    "employment_type": ["FULL_TIME", "CONTRACTOR", "INTERN"],
    "task_status": ["BLOCKED", "PENDING", "IN_PROGRESS", "COMPLETED", "CANCELLED"],
    "priority": ["LOW", "MEDIUM", "HIGH", "URGENT"],
    "grant_status": ["PENDING", "ACTIVE", "REVOKED"],
    "asset_status": ["IN_STOCK", "ASSIGNED", "IN_REPAIR", "RECOVERED", "RETIRED"],
    "case_status": ["OPEN", "IN_PROGRESS", "COMPLETED", "CANCELLED"],
    "audit_action": ["CASE_CREATED", "TASK_CREATED", "TASK_STATUS_CHANGED", "ACCESS_APPROVED",
                     "ACCESS_GRANTED", "ACCESS_REVOKED", "ASSET_ASSIGNED", "ASSET_ACKNOWLEDGED",
                     "ASSET_RECOVERED", "EMPLOYEE_TERMINATED", "EXCEPTION_RAISED", "OVERRIDE"],
}

DEPARTMENTS = [
    ("DEP-001", "Engineering"), ("DEP-002", "Data"), ("DEP-003", "Human Resources"),
    ("DEP-004", "Finance"), ("DEP-005", "Operations"), ("DEP-006", "Sales"),
]
ROLES = [
    ("ROLE-001", "Software Engineer", "DEP-001", "STANDARD"),
    ("ROLE-002", "Data Analyst", "DEP-002", "STANDARD"),
    ("ROLE-003", "HR Associate", "DEP-003", "RESTRICTED"),
    ("ROLE-004", "Finance Analyst", "DEP-004", "RESTRICTED"),
    ("ROLE-005", "IT Support Engineer", "DEP-005", "PRIVILEGED"),
    ("ROLE-006", "Sales Associate", "DEP-006", "STANDARD"),
    ("ROLE-007", "Engineering Contractor", "DEP-001", "LIMITED"),
    ("ROLE-008", "Data Intern", "DEP-002", "LIMITED"),
]
TASK_TEMPLATES = [
    ("HR_DOCUMENTS", "HR", 0, 2, []),
    ("IDENTITY_VERIFICATION", "HR", 0, 1, ["HR_DOCUMENTS"]),
    ("MANAGER_APPROVAL", "MANAGER", 0, 1, ["IDENTITY_VERIFICATION"]),
    ("ACCOUNT_REQUEST", "IT", 1, 2, ["MANAGER_APPROVAL"]),
    ("ACCESS_APPROVAL", "MANAGER", 1, 1, ["ACCOUNT_REQUEST"]),
    ("DEVICE_PREPARATION", "IT", 1, 3, ["MANAGER_APPROVAL"]),
    ("FACILITIES_BADGE", "FACILITIES", 1, 2, ["IDENTITY_VERIFICATION"]),
    ("ASSET_HANDOVER", "IT", 2, 1, ["DEVICE_PREPARATION"]),
]
ACCESS_ROLES = [
    ("AR-001", "EMAIL_STANDARD", "STANDARD", "All employees"),
    ("AR-002", "HRIS_BASIC", "RESTRICTED", "HR and managers"),
    ("AR-003", "FINANCE_ERP", "RESTRICTED", "Finance employees"),
    ("AR-004", "SOURCE_CODE", "STANDARD", "Engineering employees"),
    ("AR-005", "CLOUD_ADMIN", "PRIVILEGED", "Approved IT administrators"),
    ("AR-006", "ANALYTICS_READ", "STANDARD", "Data employees"),
    ("AR-007", "CRM_USER", "STANDARD", "Sales employees"),
]
ASSET_TYPES = ["LAPTOP", "MONITOR", "MOBILE", "ACCESS_CARD"]
ROLE_ACCESS = {
    "ROLE-001": ["AR-001", "AR-004"],
    "ROLE-002": ["AR-001", "AR-006"],
    "ROLE-003": ["AR-001", "AR-002"],
    "ROLE-004": ["AR-001", "AR-003"],
    "ROLE-005": ["AR-001", "AR-005"],
    "ROLE-006": ["AR-001", "AR-007"],
    "ROLE-007": ["AR-001", "AR-004"],
    "ROLE-008": ["AR-001", "AR-006"],
}

def iso(d: date | None) -> str | None:
    return d.isoformat() if d else None

def dt(d: date, hour: int = 9) -> str:
    return datetime(d.year, d.month, d.day, hour, 0, 0).isoformat()

def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

def checksum(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def generate(scale: str = "full", output: str | Path = "data", seed: int = SEED) -> dict[str, Any]:
    """Generate deterministic source records, labelled anomalies, exports and SQLite DB."""
    rng = random.Random(seed)
    out = Path(output)
    out.mkdir(parents=True, exist_ok=True)
    n_employees = 100 if scale == "starter" else 1000
    n_tasks = 800 if scale == "starter" else 8000
    n_grants = 150 if scale == "starter" else 1500
    n_assets = 120 if scale == "starter" else 1200

    departments = [{"department_id": d, "department_name": name, "cost_center": f"CC-{i:03d}",
                    "active": True} for i, (d, name) in enumerate(DEPARTMENTS, 1)]
    roles = [{"role_id": rid, "role_name": name, "department_id": dep, "access_tier": tier,
              "active": True} for rid, name, dep, tier in ROLES]
    managers = []
    for i in range(1, 31):
        dep = DEPARTMENTS[(i - 1) % len(DEPARTMENTS)][0]
        managers.append({"manager_id": f"MGR-{i:04d}", "manager_name": f"Manager {i:03d}",
                         "department_id": dep, "email": f"manager{i:03d}@example.test",
                         "active": True})

    employees = []
    onboarding = []
    employee_start = {}
    employee_role = {}
    employee_mgr = {}
    employee_dept = {}
    employee_type = {}
    for i in range(1, n_employees + 1):
        emp_id = f"EMP-{i:06d}"
        role = ROLES[(i - 1) % len(ROLES)]
        role_id, role_name, dep_id, tier = role
        mgr = managers[(i - 1) % len(managers)]
        # Starts distributed over a year; some deliberately delayed.
        start = BASE_DATE + timedelta(days=rng.randint(0, 300))
        if i % 23 == 0:
            start += timedelta(days=rng.randint(7, 25))
        hire_date = start - timedelta(days=rng.randint(7, 35))
        emp_type = "CONTRACTOR" if i % 13 == 0 else ("INTERN" if i % 17 == 0 else "FULL_TIME")
        status = "TERMINATED" if i % 41 == 0 else ("PREBOARDING" if start > date(2026, 11, 1) else "ACTIVE")
        termination_date = (start + timedelta(days=rng.randint(30, 220))) if status == "TERMINATED" else None
        # Termination may legitimately fall in the next calendar year.
        if status == "TERMINATED":
            status = "TERMINATED"
        employees.append({
            "employee_id": emp_id, "first_name": f"Employee{i:04d}", "last_name": f"Sample{i:04d}",
            "email": f"employee{i:04d}@example.test", "role_id": role_id, "department_id": dep_id,
            "manager_id": mgr["manager_id"], "employment_type": emp_type, "hire_date": iso(hire_date),
            "start_date": iso(start), "termination_date": iso(termination_date),
            "employment_status": status, "location": ["Hyderabad", "Bengaluru", "Pune"][i % 3],
            "issue_type": ""
        })
        employee_start[emp_id] = start
        employee_role[emp_id] = role_id
        employee_mgr[emp_id] = mgr["manager_id"]
        employee_dept[emp_id] = dep_id
        employee_type[emp_id] = emp_type
        case_id = f"ONB-2026-{i:06d}"
        onboarding.append({"onboarding_case_id": case_id, "employee_id": emp_id,
                           "case_status": "COMPLETED" if status == "ACTIVE" else ("OPEN" if status == "PREBOARDING" else "COMPLETED"),
                           "created_at": dt(hire_date), "target_start_date": iso(start),
                           "actual_start_date": iso(start) if status in ("ACTIVE", "TERMINATED") else None,
                           "hr_owner": f"HR-{(i % 12) + 1:03d}", "issue_type": ""})

    # Employee role changes are stored as explicit audit events; current role stays on Employee.
    audit = []
    for i, emp in enumerate(employees, 1):
        if i % 37 == 0:
            audit.append({"audit_event_id": f"AUD-{len(audit)+1:07d}", "entity_type": "Employee",
                          "entity_id": emp["employee_id"], "event_time": dt(BASE_DATE + timedelta(days=180)),
                          "action": "OVERRIDE", "old_value": emp["role_id"], "new_value": emp["role_id"],
                          "actor": "HR_SYSTEM", "reason": "Role review recorded; no current role change",
                          "correlation_id": emp["employee_id"]})

    tasks = []
    dependencies = []
    task_id_by_case_template = defaultdict(dict)
    # Exactly n_tasks tasks: first create a realistic core workflow, then operational follow-ups.
    for i, emp in enumerate(employees, 1):
        case_id = f"ONB-2026-{i:06d}"
        count_for_emp = 8
        for j, (template, owner, offset, duration, prereqs) in enumerate(TASK_TEMPLATES, 1):
            task_id = f"TASK-{case_id}-{j:03d}"
            due = employee_start[emp["employee_id"]] - timedelta(days=offset)
            task_status = "COMPLETED" if emp["employment_status"] in ("ACTIVE", "TERMINATED") else "PENDING"
            if task_status == "COMPLETED":
                completed = due - timedelta(days=1)
            else:
                completed = None
            tasks.append({"task_id": task_id, "case_id": case_id, "employee_id": emp["employee_id"],
                          "task_type": template, "owner_type": owner, "assigned_to": f"{owner}-QUEUE",
                          "status": task_status, "priority": "HIGH" if template in ("ACCESS_APPROVAL", "ASSET_HANDOVER") else "MEDIUM",
                          "created_at": dt(due - timedelta(days=5)), "due_date": iso(due),
                          "completed_at": iso(completed), "issue_type": ""})
            task_id_by_case_template[case_id][template] = task_id
            for prereq in prereqs:
                dependencies.append({"dependency_id": f"DEP-{len(dependencies)+1:07d}",
                                     "task_id": task_id, "prerequisite_task_id": task_id_by_case_template[case_id].get(prereq, ""),
                                     "dependency_type": "FINISH_TO_START"})
        # add 0-? task extras later

    # Add extra tasks to reach requested volume, preserving valid case and employee references.
    while len(tasks) < n_tasks:
        idx = len(tasks) + 1
        emp_idx = ((idx - 1) % n_employees) + 1
        emp_id = f"EMP-{emp_idx:06d}"
        case_id = f"ONB-2026-{emp_idx:06d}"
        task_num = sum(1 for t in tasks if t["case_id"] == case_id) + 1
        task_id = f"TASK-{case_id}-{task_num:03d}"
        due = employee_start[emp_id] - timedelta(days=rng.randint(0, 5))
        tasks.append({"task_id": task_id, "case_id": case_id, "employee_id": emp_id,
                      "task_type": ["SECURITY_TRAINING", "POLICY_ACKNOWLEDGEMENT", "WELCOME_SESSION"][idx % 3],
                      "owner_type": ["HR", "IT", "MANAGER"][idx % 3], "assigned_to": "WORKFLOW-QUEUE",
                      "status": "COMPLETED" if employees[emp_idx-1]["employment_status"] != "PREBOARDING" else "PENDING",
                      "priority": "LOW", "created_at": dt(due - timedelta(days=3)), "due_date": iso(due),
                      "completed_at": iso(due - timedelta(days=1)) if employees[emp_idx-1]["employment_status"] != "PREBOARDING" else None,
                      "issue_type": ""})

    # Access grants: baseline grants only for eligible employees, with approvals before activation.
    grants = []
    grant_counter = defaultdict(int)
    eligible_ids = [e["employee_id"] for e in employees if e["employment_status"] in ("ACTIVE", "TERMINATED")]
    # One or two grants per employee to target volume.
    for i in range(n_grants):
        emp_id = eligible_ids[i % len(eligible_ids)]
        role_id = employee_role[emp_id]
        allowed = ROLE_ACCESS[role_id]
        access_role_id = allowed[i % len(allowed)]
        grant_counter[emp_id] += 1
        grant_id = f"GRANT-{emp_id}-{grant_counter[emp_id]:03d}"
        start = employee_start[emp_id]
        approved = start - timedelta(days=1)
        grant_start = start
        grant_status = "ACTIVE"
        emp = employees[int(emp_id.split("-")[1]) - 1]
        if emp["employment_status"] == "TERMINATED" and emp["termination_date"]:
            term = date.fromisoformat(emp["termination_date"])
            grant_status = "REVOKED"
        else:
            term = None
        grants.append({"access_grant_id": grant_id, "employee_id": emp_id, "access_role_id": access_role_id,
                       "requested_at": dt(approved - timedelta(days=2)), "approved_at": dt(approved),
                       "granted_at": dt(grant_start), "revoked_at": dt(term) if term else None,
                       "grant_status": grant_status, "approved_by": employee_mgr[emp_id],
                       "issue_type": ""})

    # Assets: inventory with assignments; only assets assigned to employee once in baseline.
    assets = []
    assigned_asset_emp = {}
    for i in range(1, n_assets + 1):
        asset_id = f"AST-{i:06d}"
        asset_type = ASSET_TYPES[(i - 1) % len(ASSET_TYPES)]
        emp_id = eligible_ids[(i - 1) % len(eligible_ids)] if i <= min(n_assets, len(eligible_ids)) else None
        status = "ASSIGNED" if emp_id else "IN_STOCK"
        assigned_date = employee_start[emp_id] if emp_id else None
        assets.append({"asset_id": asset_id, "asset_type": asset_type, "serial_number": f"SN-{i:08d}",
                       "manufacturer": ["Dell", "HP", "Lenovo", "Apple"][i % 4],
                       "asset_status": status, "assigned_employee_id": emp_id,
                       "assigned_date": iso(assigned_date), "acknowledged_at": dt(assigned_date, 10) if assigned_date else None,
                       "recovered_at": None, "issue_type": ""})
        if emp_id:
            assigned_asset_emp[asset_id] = emp_id

    offboarding = []
    for emp in employees:
        if emp["employment_status"] == "TERMINATED":
            i = int(emp["employee_id"].split("-")[1])
            off_id = f"OFF-2026-{i:06d}"
            term = emp["termination_date"]
            offboarding.append({"offboarding_case_id": off_id, "employee_id": emp["employee_id"],
                                "initiated_at": dt(date.fromisoformat(term) - timedelta(days=1)),
                                "effective_termination_date": term, "case_status": "COMPLETED",
                                "reason_category": "CONTRACT_END" if emp["employment_type"] == "CONTRACTOR" else "VOLUNTARY",
                                "issue_type": ""})

    # Add explicit offboarding task rows for termination cases.
    for off in offboarding:
        emp_id = off["employee_id"]
        for k, typ in enumerate(["REVOKE_ACCESS", "RECOVER_ASSETS"], 1):
            tasks.append({"task_id": f"TASK-{off['offboarding_case_id']}-{k:03d}", "case_id": off["offboarding_case_id"],
                          "employee_id": emp_id, "task_type": typ, "owner_type": "IT" if k == 1 else "FACILITIES",
                          "assigned_to": "OFFBOARDING-QUEUE", "status": "COMPLETED", "priority": "URGENT",
                          "created_at": dt(date.fromisoformat(off["effective_termination_date"]) - timedelta(days=1)),
                          "due_date": off["effective_termination_date"], "completed_at": off["effective_termination_date"],
                          "issue_type": ""})

    # Reconcile target task count after offboarding task additions.
    while len(tasks) > n_tasks:
        tasks.pop()
    while len(tasks) < n_tasks:
        idx = len(tasks) + 1
        emp_idx = ((idx - 1) % n_employees) + 1
        emp_id = f"EMP-{emp_idx:06d}"
        case_id = f"ONB-2026-{emp_idx:06d}"
        seq = sum(1 for t in tasks if t["case_id"] == case_id) + 1
        due = employee_start[emp_id]
        tasks.append({"task_id": f"TASK-{case_id}-{seq:03d}", "case_id": case_id, "employee_id": emp_id,
                      "task_type": "FOLLOW_UP", "owner_type": "HR", "assigned_to": "HR-QUEUE",
                      "status": "PENDING", "priority": "LOW", "created_at": dt(due - timedelta(days=2)),
                      "due_date": iso(due), "completed_at": None, "issue_type": ""})

    # Rebuild dependencies to ensure every prerequisite reference exists; base workflow dependencies.
    dependencies = []
    for case_id, mapping in task_id_by_case_template.items():
        for template, prereqs in [(x[0], x[4]) for x in TASK_TEMPLATES]:
            for prereq in prereqs:
                if prereq in mapping:
                    dependencies.append({"dependency_id": f"DEP-{len(dependencies)+1:07d}",
                                         "task_id": mapping[template], "prerequisite_task_id": mapping[prereq],
                                         "dependency_type": "FINISH_TO_START"})

    # Audit events for material lifecycle events.
    def add_audit(entity_type, entity_id, event_date, action, old="", new="", actor="WORKFLOW",
                  reason="", corr=""):
        audit.append({"audit_event_id": f"AUD-{len(audit)+1:07d}", "entity_type": entity_type,
                      "entity_id": entity_id, "event_time": dt(event_date), "action": action,
                      "old_value": old, "new_value": new, "actor": actor, "reason": reason,
                      "correlation_id": corr or entity_id})
    for case in onboarding:
        add_audit("OnboardingCase", case["onboarding_case_id"], date.fromisoformat(case["created_at"][:10]),
                  "CASE_CREATED", new=case["case_status"], actor="HR_SYSTEM")
    for grant in grants:
        add_audit("AccessGrant", grant["access_grant_id"], date.fromisoformat(grant["approved_at"][:10]),
                  "ACCESS_APPROVED", new=grant["access_role_id"], actor=grant["approved_by"])
        if grant["grant_status"] == "ACTIVE":
            add_audit("AccessGrant", grant["access_grant_id"], date.fromisoformat(grant["granted_at"][:10]),
                      "ACCESS_GRANTED", new="ACTIVE", actor="IT_SYSTEM")
        else:
            add_audit("AccessGrant", grant["access_grant_id"], date.fromisoformat(grant["revoked_at"][:10]),
                      "ACCESS_REVOKED", old="ACTIVE", new="REVOKED", actor="IT_SYSTEM")
    for asset in assets:
        if asset["assigned_employee_id"]:
            add_audit("Asset", asset["asset_id"], date.fromisoformat(asset["assigned_date"]),
                      "ASSET_ASSIGNED", new=asset["assigned_employee_id"], actor="IT_SYSTEM")
            add_audit("Asset", asset["asset_id"], date.fromisoformat(asset["acknowledged_at"][:10]),
                      "ASSET_ACKNOWLEDGED", new="ACKNOWLEDGED", actor=asset["assigned_employee_id"])
    for off in offboarding:
        add_audit("OffboardingCase", off["offboarding_case_id"],
                  date.fromisoformat(off["effective_termination_date"]), "EMPLOYEE_TERMINATED",
                  old="ACTIVE", new="TERMINATED", actor="HR_SYSTEM")

    # Separate, documented anomaly injection: exactly one labelled case per required scenario.
    ground_truth = []
    def label(anomaly_id, issue_type, entity_type, entity_id, expected_decision, description):
        ground_truth.append({"anomaly_id": anomaly_id, "issue_type": issue_type, "entity_type": entity_type,
                             "entity_id": entity_id, "expected_decision": expected_decision,
                             "description": description, "detected": False})

    # 1. Access before employment start/approval.
    if grants:
        g = grants[0]
        g["granted_at"] = dt(employee_start[g["employee_id"]] - timedelta(days=2))
        g["issue_type"] = "ACCESS_BEFORE_START"
        label("GT-001", "ACCESS_BEFORE_START", "AccessGrant", g["access_grant_id"],
              "QUARANTINE_AND_REQUIRE_APPROVAL", "Grant timestamp precedes employee start date.")
        add_audit("AccessGrant", g["access_grant_id"], employee_start[g["employee_id"]] - timedelta(days=2),
                  "EXCEPTION_RAISED", reason="Access granted before start date", actor="VALIDATION_ENGINE")

    # 2. Duplicate asset assignment: second asset points to same employee and is marked.
    if len(assets) > 2:
        a1, a2 = assets[0], assets[1]
        a2["assigned_employee_id"] = a1["assigned_employee_id"]
        a2["asset_status"] = "ASSIGNED"
        a2["issue_type"] = "DUPLICATE_ASSET_ASSIGNMENT"
        label("GT-002", "DUPLICATE_ASSET_ASSIGNMENT", "Asset", a2["asset_id"],
              "FLAG_DUPLICATE_AND_REVIEW", "Same employee has multiple assigned devices in the synthetic exception case.")
        add_audit("Asset", a2["asset_id"], date.fromisoformat(a2["assigned_date"]),
                  "EXCEPTION_RAISED", reason="Duplicate employee asset assignment", actor="VALIDATION_ENGINE")

    # 3. Terminated employee retains active grant.
    terminated = next((e for e in employees if e["employment_status"] == "TERMINATED"), None)
    if terminated:
        g = next((x for x in grants if x["employee_id"] == terminated["employee_id"]), None)
        if g:
            g["grant_status"] = "ACTIVE"
            g["revoked_at"] = None
            g["issue_type"] = "TERMINATED_EMPLOYEE_ACTIVE_GRANT"
            label("GT-003", "TERMINATED_EMPLOYEE_ACTIVE_GRANT", "AccessGrant", g["access_grant_id"],
                  "REVOKE_IMMEDIATELY_AND_ESCALATE", "Terminated employee still has an active access grant.")
            add_audit("AccessGrant", g["access_grant_id"], date.fromisoformat(terminated["termination_date"]),
                      "EXCEPTION_RAISED", old="REVOKED", new="ACTIVE",
                      reason="Active grant remains after termination", actor="VALIDATION_ENGINE")

    # 4. Dependency cycle: two valid task IDs linked in a cycle.
    if len(tasks) >= 2:
        t1, t2 = tasks[0], tasks[1]
        dependencies.append({"dependency_id": f"DEP-{len(dependencies)+1:07d}", "task_id": t1["task_id"],
                             "prerequisite_task_id": t2["task_id"], "dependency_type": "FINISH_TO_START"})
        dependencies.append({"dependency_id": f"DEP-{len(dependencies)+1:07d}", "task_id": t2["task_id"],
                             "prerequisite_task_id": t1["task_id"], "dependency_type": "FINISH_TO_START"})
        t1["issue_type"] = "TASK_DEPENDENCY_CYCLE"
        label("GT-004", "TASK_DEPENDENCY_CYCLE", "Dependency", dependencies[-2]["dependency_id"],
              "BLOCK_WORKFLOW_AND_REMOVE_CYCLE", "Two task nodes depend on each other.")
        add_audit("Dependency", dependencies[-2]["dependency_id"], BASE_DATE,
                  "EXCEPTION_RAISED", reason="Task dependency cycle injected", actor="VALIDATION_ENGINE")

    # 5. Recovered asset still shows assigned employee.
    # Keep the deliberate duplicate pair intact; use a third asset for the recovery anomaly.
    recovered = next((a for a in assets[2:] if a["asset_status"] == "ASSIGNED"), None)
    if recovered:
        recovered["asset_status"] = "RECOVERED"
        recovered["recovered_at"] = dt(date.fromisoformat(recovered["assigned_date"]) + timedelta(days=30))
        recovered["issue_type"] = "RECOVERED_ASSET_STILL_ASSIGNED"
        label("GT-005", "RECOVERED_ASSET_STILL_ASSIGNED", "Asset", recovered["asset_id"],
              "CLEAR_ASSIGNMENT_AND_RECONCILE_INVENTORY", "Asset is marked recovered but still references an assigned employee.")
        add_audit("Asset", recovered["asset_id"], date.fromisoformat(recovered["recovered_at"][:10]),
                  "ASSET_RECOVERED", old="ASSIGNED", new="RECOVERED", actor="FACILITIES")
        add_audit("Asset", recovered["asset_id"], date.fromisoformat(recovered["recovered_at"][:10]),
                  "EXCEPTION_RAISED", reason="Recovered asset retains assigned employee ID", actor="VALIDATION_ENGINE")

    tables = {
        "Department": departments, "Role": roles, "Manager": managers, "Employee": employees,
        "OnboardingCase": onboarding, "Task": tasks, "Dependency": dependencies,
        "AccessRole": [{"access_role_id": a, "access_role_name": b, "access_tier": c, "description": d}
                       for a, b, c, d in ACCESS_ROLES],
        "AccessGrant": grants, "Asset": assets, "OffboardingCase": offboarding, "AuditEvent": audit,
    }

    # CSV and JSON exports.
    for name, rows in tables.items():
        write_csv(out / f"{name.lower()}.csv", rows)
        (out / f"{name.lower()}.json").write_text(json.dumps(rows, indent=2), encoding="utf-8")
    write_csv(out / "ground_truth.csv", ground_truth)
    (out / "ground_truth.json").write_text(json.dumps(ground_truth, indent=2), encoding="utf-8")

    # SQLite schema + data. FK constraints are enabled during insertion.
    db_path = out / "lifecycle.db"
    if db_path.exists():
        db_path.unlink()
    conn = sqlite3.connect(db_path)
    conn.execute("PRAGMA foreign_keys = ON")
    schema = """
    CREATE TABLE Department(department_id TEXT PRIMARY KEY, department_name TEXT NOT NULL UNIQUE, cost_center TEXT NOT NULL UNIQUE, active INTEGER NOT NULL);
    CREATE TABLE Manager(manager_id TEXT PRIMARY KEY, manager_name TEXT NOT NULL, department_id TEXT NOT NULL REFERENCES Department(department_id), email TEXT NOT NULL UNIQUE, active INTEGER NOT NULL);
    CREATE TABLE Role(role_id TEXT PRIMARY KEY, role_name TEXT NOT NULL UNIQUE, department_id TEXT NOT NULL REFERENCES Department(department_id), access_tier TEXT NOT NULL, active INTEGER NOT NULL);
    CREATE TABLE Employee(employee_id TEXT PRIMARY KEY, first_name TEXT NOT NULL, last_name TEXT NOT NULL, email TEXT NOT NULL UNIQUE, role_id TEXT NOT NULL REFERENCES Role(role_id), department_id TEXT NOT NULL REFERENCES Department(department_id), manager_id TEXT NOT NULL REFERENCES Manager(manager_id), employment_type TEXT NOT NULL, hire_date TEXT NOT NULL, start_date TEXT NOT NULL, termination_date TEXT, employment_status TEXT NOT NULL, location TEXT NOT NULL, issue_type TEXT NOT NULL);
    CREATE TABLE OnboardingCase(onboarding_case_id TEXT PRIMARY KEY, employee_id TEXT NOT NULL UNIQUE REFERENCES Employee(employee_id), case_status TEXT NOT NULL, created_at TEXT NOT NULL, target_start_date TEXT NOT NULL, actual_start_date TEXT, hr_owner TEXT NOT NULL, issue_type TEXT NOT NULL);
    CREATE TABLE Task(task_id TEXT PRIMARY KEY, case_id TEXT NOT NULL, employee_id TEXT NOT NULL REFERENCES Employee(employee_id), task_type TEXT NOT NULL, owner_type TEXT NOT NULL, assigned_to TEXT NOT NULL, status TEXT NOT NULL, priority TEXT NOT NULL, created_at TEXT NOT NULL, due_date TEXT NOT NULL, completed_at TEXT, issue_type TEXT NOT NULL);
    CREATE TABLE Dependency(dependency_id TEXT PRIMARY KEY, task_id TEXT NOT NULL REFERENCES Task(task_id), prerequisite_task_id TEXT NOT NULL REFERENCES Task(task_id), dependency_type TEXT NOT NULL);
    CREATE TABLE AccessRole(access_role_id TEXT PRIMARY KEY, access_role_name TEXT NOT NULL UNIQUE, access_tier TEXT NOT NULL, description TEXT NOT NULL);
    CREATE TABLE AccessGrant(access_grant_id TEXT PRIMARY KEY, employee_id TEXT NOT NULL REFERENCES Employee(employee_id), access_role_id TEXT NOT NULL REFERENCES AccessRole(access_role_id), requested_at TEXT NOT NULL, approved_at TEXT NOT NULL, granted_at TEXT NOT NULL, revoked_at TEXT, grant_status TEXT NOT NULL, approved_by TEXT NOT NULL, issue_type TEXT NOT NULL);
    CREATE TABLE Asset(asset_id TEXT PRIMARY KEY, asset_type TEXT NOT NULL, serial_number TEXT NOT NULL UNIQUE, manufacturer TEXT NOT NULL, asset_status TEXT NOT NULL, assigned_employee_id TEXT REFERENCES Employee(employee_id), assigned_date TEXT, acknowledged_at TEXT, recovered_at TEXT, issue_type TEXT NOT NULL);
    CREATE TABLE OffboardingCase(offboarding_case_id TEXT PRIMARY KEY, employee_id TEXT NOT NULL UNIQUE REFERENCES Employee(employee_id), initiated_at TEXT NOT NULL, effective_termination_date TEXT NOT NULL, case_status TEXT NOT NULL, reason_category TEXT NOT NULL, issue_type TEXT NOT NULL);
    CREATE TABLE AuditEvent(audit_event_id TEXT PRIMARY KEY, entity_type TEXT NOT NULL, entity_id TEXT NOT NULL, event_time TEXT NOT NULL, action TEXT NOT NULL, old_value TEXT NOT NULL, new_value TEXT NOT NULL, actor TEXT NOT NULL, reason TEXT NOT NULL, correlation_id TEXT NOT NULL);
    """
    conn.executescript(schema)
    for name, rows in tables.items():
        if not rows:
            continue
        cols = list(rows[0].keys())
        placeholders = ",".join("?" for _ in cols)
        # Use explicit table names and insertion order matching schema.
        conn.executemany(f'INSERT INTO "{name}" ({",".join(cols)}) VALUES ({placeholders})',
                         [[r.get(c) for c in cols] for r in rows])
    conn.commit()
    fk_errors = conn.execute("PRAGMA foreign_key_check").fetchall()
    conn.close()

    # Validation summary. Intentional anomalies are separately identified and excluded from baseline checks.
    checks = {
        "primary_key_uniqueness": True,
        "foreign_key_integrity": len(fk_errors) == 0,
        "required_row_counts": {
            "employees": len(employees) == n_employees,
            "tasks": len(tasks) == n_tasks,
            "access_grants": len(grants) == n_grants,
            "assets": len(assets) == n_assets,
        },
        "ground_truth_count": len(ground_truth),
        "foreign_key_errors": fk_errors,
        "anomalies_injected": [g["issue_type"] for g in ground_truth],
        "seed": seed,
        "scale": scale,
    }
    (out / "validation_summary.json").write_text(json.dumps(checks, indent=2), encoding="utf-8")
    manifest = {
        "project": "Employee Lifecycle Workflow Automation & Audit System",
        "seed": seed, "scale": scale, "generated_at": "deterministic-seed-run",
        "synthetic_only": True, "external_sources": [],
        "row_counts": {k: len(v) for k, v in tables.items()},
        "checksums_sha256": {p.name: checksum(p) for p in sorted(out.iterdir()) if p.is_file() and p.name != "source_manifest.json"},
    }
    (out / "source_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return {"tables": tables, "ground_truth": ground_truth, "checks": checks, "manifest": manifest}

def main():
    parser = argparse.ArgumentParser(description="Generate employee lifecycle synthetic data.")
    parser.add_argument("--scale", choices=["starter", "full"], default="full")
    parser.add_argument("--output", default="data")
    parser.add_argument("--seed", type=int, default=SEED)
    args = parser.parse_args()
    result = generate(args.scale, args.output, args.seed)
    print(json.dumps({"scale": args.scale, "seed": args.seed, "row_counts": result["manifest"]["row_counts"],
                      "ground_truth": len(result["ground_truth"]), "validation": result["checks"]}, indent=2))

if __name__ == "__main__":
    main()
